ELEVATE TAX SERVICES WEBSITE — VERSION 1

Files:
- index.html — Main website
- store.html — eBook store/library
- book-2026-tax-guide.html — Main book sales page
- client-login.html — Placeholder for future secure client portal
- styles.css — Website design

IMPORTANT:
The Client Login, booking buttons, Stripe payment button, secure tax intake forms,
and private document upload are placeholders. Do not collect sensitive client
tax information until a secure backend/portal is connected.

UPLOAD TO GITHUB:
1. Create a new GitHub repository.
2. Upload all files from this folder.
3. Connect the repository to Cloudflare Pages.
4. The site will publish with index.html as the home page.
